import { Typography } from "@mui/material";
export default function Typo() {
    return (
        <div>
            <Typography variant="h1">Hey there</Typography> 
        </div> 
    )
}