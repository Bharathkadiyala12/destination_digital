import { Button } from "@mui/material";

export default function ButtonX(){
    return(
        <Button variant = 'contained' color = 'info'>Click Here!</Button>
    )
}