import * as React from "react";
import CssBaseline from "@mui/material/CssBaseline";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import { Typography } from "@mui/material";
import Button from '@mui/material/Button';
import DeleteIcon from '@mui/icons-material/Delete';
import SendIcon from '@mui/icons-material/Send';
import Stack from '@mui/material/Stack';
import logo from "../../src/components/logos/laptop-phone-paperplane.png";

export default function SimpleContainer() {
  return (
    <React.Fragment>
      <CssBaseline />
      <Container
        maxWidth="xl"
        sx={{ bgcolor: "white", height: "100vh", display: "flex" }}
      >
        <Box
          my={4}
          display="block"
          alignItems="center"
          gap={4}
          p={2}
          sx={{
            width: "100%",
            maxWidth: 500,
            border: "1px dashed grey",
            maxHeight: 600,
            marginLeft: 40,
            paddingTop: 5,
          }}
        >
          <Typography variant="h4" gutterBottom sx = {{marginBottom: 7, fontWeight: "bold"}}>
            Get started with online and mobile banking
          </Typography>
          <Typography variant="h6" gutterBottom sx = {{marginBottom: 4}}>
            To make this a breeze, please have your BMO credit card handy.
          </Typography>
          <Typography variant="h6" gutterBottom sx = {{}}>
            You'll enter your card details and then create a password.
          </Typography>
          <Button variant="contained" size="large" sx={{justifyContent: 'center', marginTop: 6,marginLeft: 1, fontWeight: 'bold', width: "20vh"}}>
          Next
        </Button>
        </Box>

        <Box
          my={4}
          display="block"
          alignItems="center"
          gap={4}
          p={2}
          sx={{
            width: "100%",
            maxWidth: 300,
            border: "1px dashed grey",
            maxHeight: 600,
            marginLeft: 10,
            alignContent: "center",
          }}
        >
          <img src={logo} />
        </Box>
      </Container>
    </React.Fragment>
  );
}
