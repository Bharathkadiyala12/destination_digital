import "./App.css";
import Button from "./components/Button";
import ResponsiveAppBar from "./components/Nav";
import Typo from "./components/typogrpahy";

function App() {
  return (
    <div className="App">
      <Typo/>
      <Button/>
    </div>
  );
}

export default App;
